<?php

session_start();
include "koneksi.php";
if(!isset($_session['username'])){
    header ("location:login.php");
}

if(isset($_session['username'])){
    $username = $_session['username'];
}

?>

<html>
    <head>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
        <title>E-Learning USU</title>
        <link rel="icon" href="usu.png">
    </head>

    <body>
        <!-- header start -->
        <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
            <a class="navbar-brand" href="#"><img src="usu.png" style="max-height: 44px"></a>

        </nav>

        </body>

</html>

        <table class="table table-striped" style="text-align: center">
  <thead class="table-dark">
      <th>No.</th>
      <th>Nim</th>
      <th>Nama</th>
      <th>Gender</th>
      <th>Alamat</th>
      <th>Opsi</th>
      <th scope="col">First</th>
      <th scope="col">Last</th>
      <th scope="col">Handle</th>
  </thead>
  


<?php
include_once 'koneksi.php';
$no=1;
$data=mysqli_query($koneksi, "select * from mahasiswa");
while ($d = mysqli_fetch_array($data)){



    ?>

    <tr>

    <td><?php echo $no++; ?></td>
    <td><?php echo $d['nim']; ?></td>
    <td><?php echo $d['nama']; ?></td>
    <td><?php echo $d['gender']; ?></td>
    <td><?php echo $d['alamat']; ?></td>
    <td>
    <a href="edit.php ?nim=<?php echo $d['nim'];?>">edit</a>
    <a href="hapus.php ?nim=<?php echo $d['nim'];?>">hapus</a>

</td>
    
    </tr>

    <?php
}

?>