<?php

$servername = "localhost";
$username = "root";
$password = "";
$database = "mahasiswa";

//konek ke database

$connection=mysqli_connect($servername, $username, $password, $database);


//cek koneksi


if (!$connection) {

    die("Connection failed: " . mysqli_connect_error());
}

echo "Connected succesfully";

?>