<html>

<head>
    <title>Login</title>
</head>

<body>
    LOGIN
    <form method="post" action="aksi_login.php">
        <input class="masuk" type="text" autocomplete="off" placeholder="Your Name" name="username" autofocus
            required><br />
        <input class="masuk" type="password" autocomplete="off" placeholder="Your Password" name="password"
            required><br />
        <input id="tombol" type="submit" value="Login">
    </form>
</body>

</html>