<html>
<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
<title>E-Learning USU</title>
<link rel="icon" href="usu.png">
</head>


<body>

<h3>
    <a href="index.php">Kembali</a><br>
    <p>Tambah Data Mahasiswa</p>
</h3>



<form action="tambah_proses.php" method="post">


    <table>

    <tr>

    <td>Nim</td>
    <td>:</td>
    <td>
        <input type="number" name="nim" required>
    </td>

    </tr>

    <tr>

<td>Nama Lengkap</td>
<td>:</td>
<td>
    <input type="text" name="nama" required>
</td>

</tr>


<tr>


    <td>Gender</td>
    <td>:</td>

<td>
        <select name="gender" required>
            <option value="">Pilih</option>
            <option value="Pria" <?php if($d['gender'] == 'Pria'){echo 'selected';} ?>> Pria</option>
            <option value="Wanita" <?php if($d['gender'] == 'Wanita'){echo 'selected';} ?>> Wanita</option>
        </select>
    </td>

    </tr>

    <tr>
        <td>Alamat</td>
        <td>:</td>
        <td>
        <input type="text" name="alamat" required>
        </td>
    </tr>

    <tr>
        <td>&nbsp;</td>
        <td></td>
        <td><input type="submit" name="tambah" value="Tambah"></td>
    </tr>

    </table>

</form>


</body>

</html>